class Component
  def operation
    raise NotImplementedError, "Subclasses must implement this method"
  end
end

class Leaf < Component
  def operation
    puts "Leaf operation"
  end
end

class Composite < Component
  def initialize
    @children = []
  end

  def add(child)
    @children << child
  end

  def remove(child)
    @children.delete(child)
  end

  def operation
    puts "Composite operation"
    @children.each { |child| child.operation }
  end
end

# Использование

leaf1 = Leaf.new
leaf2 = Leaf.new

composite = Composite.new
composite.add(leaf1)
composite.add(leaf2)

composite.operation